# Use LuaLaTeX for PDF generation
# Run with: latexmk pset1_ECON1550.tex
$pdf_mode = 4;  # 4 = lualatex
$lualatex = 'lualatex -synctex=1 -interaction=nonstopmode -file-line-error %O %S';
# Fallback: if someone runs "latexmk -pdf", still use lualatex
$pdflatex = 'lualatex -synctex=1 -interaction=nonstopmode -file-line-error %O %S';
