# Use LuaLaTeX as the default PDF generator
$pdf_mode = 4;  # 4 = lualatex
