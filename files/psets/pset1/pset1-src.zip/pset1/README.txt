ECON 1550 Problem Set Source Files
===================================

This folder contains LaTeX source files. Compile the main file:

    psetN_ECON1550.tex

where N is the problem set number.


COMPILING LOCALLY
-----------------
Requires: LuaLaTeX (included in TeX Live or MiKTeX)

Option 1 - With latexmk (recommended):
    latexmk psetN_ECON1550.tex

Option 2 - Direct compilation:
    lualatex psetN_ECON1550.tex
    (run twice for cross-references)


USING ON OVERLEAF
-----------------
Brown students get Overleaf Professional free, see: https://www.overleaf.com/edu/brown and https://libguides.brown.edu/overleaf 

1. Create a new blank project on Overleaf
2. Upload ALL files from this folder to the project root
3. Set the main document to psetN_ECON1550.tex
4. Compile

The included latexmkrc file configures LuaLaTeX automatically.


TROUBLESHOOTING
---------------
"Font not found" errors:
  - Ensure you're using LuaLaTeX, not pdfLaTeX
  - On Overleaf: Menu > Compiler > LuaLaTeX

Compilation hangs or times out:
  - First compilation may be slow (font caching)
  - Try again; subsequent builds are faster

Missing package errors:
  - Update your TeX distribution
  - On Overleaf: packages are included automatically

Other issues:
  - On Overleaf: Try "Recompile from scratch"
  - Check Canvas announcements
  - Email the course staff
