# ECON1550 Problem Set 6 Review (2026-03-10)

## Findings (ordered by severity)

### High

1. **Conceptual inconsistency in Q2e equilibrium conditions** — FIXED
   - File: `pset6_questions.tex`, lines 213–215
   - Issue: the solution stated both `q = \bar{Y}` and `q = 1` without reconciliation.
   - Fix applied: added explicit statement that PPP forces `q = EP*/P = 1`, so equilibrium requires `\bar{Y} = 1` in levels, and the key result is that `q` is unchanged after the increase in `M`.

### Medium

2. **Sample-window ambiguity across PS6 and referenced PS3 carry-trade instruction** — OPEN
   - PS6 Q1c asks Jan 2009–Aug 2023; PS3 Q2c text says "end your analysis in July 2023".
   - Not yet addressed because it requires a coordinated edit across two problem sets.

3. **DropBox link formatting is fragile for long-term reuse** — OPEN
   - The URL includes session-like `st=...` parameter and `dl=0`.
   - Not addressed; link currently works and matches the local workbook exactly.

### Low

4. **Grammar typo in Q1e solution** — FIXED
   - "The hedge carry trade" → "The hedged carry trade".

5. **Potential terminology confusion in Q1c hint** — OPEN (cosmetic)
   - Hint says "consumer price index in units of..." when the linked series are already inflation rates.

6. **Non-blocking LaTeX layout warning** — RESOLVED
   - No overfull `\hbox` warnings remain after recompilation.

---

## Formatting and cleanup applied (2026-03-10)

- Reformatted `pset6_questions.tex` to one sentence per line for cleaner git diffs.
- Removed trailing whitespace throughout.
- Renamed image references from stale `a_image{1,2,3}.png` to descriptive names:
  - `a_image1.png` → `q1c_us_korea_inflation_yoy_2009-01_to_2023-08.png`
  - `a_image2.png` → `q1d_relative_ppp_usd_overvaluation_indicator_2009-01_to_2023-08.png`
  - `a_image3.png` → `q1e_cumulative_returns_standard_vs_hedged_carry_trade_2009-02_to_2023-08.png`
- Deleted stale `a_image{1,2,3}.png` files.
- Added `\vspace{0.5em}` + `\begin{center}...\end{center}` around all `\includegraphics`.
- All three PDFs (`pset6_ECON1550.pdf`, `pset6_ECON1550_answers.pdf`, `pset6_ECON1550_answers_short.pdf`) compile cleanly with no meaningful warnings.

---

## Reproducibility and Source Audit

### Reproduction status

- Reproduced values match existing PS6 workbook (`ECON1550_pset6_q1.xlsx`) up to floating-point noise.
- Key result replicated exactly:
  - Final cumulative return (carry, Feb 2009 = 100): **136.5337573**
  - Final cumulative return (hedged carry, Feb 2009 = 100): **575.0927887**
  - Ratio hedged/standard: **4.2121x**

### Raw-data comparison status

- Existing `Resources/Data/CPGRLE01USM659N.xlsx` vs newly downloaded FRED data: max absolute difference `4.44e-16`
- Existing `Resources/Data/CPGRLE01KRM659N.xlsx` vs newly downloaded FRED data: max absolute difference `4.44e-16`
- Existing PS6 workbook vs recomputed series: exact match (max diff `0.0` for core columns)

---

## Build Check

- All three TeX targets compile successfully with `latexmk` (LuaLaTeX engine via `.latexmkrc`).
- No overfull/underfull hbox warnings in the answers build.
