# ECON1550 Problem Set 6 Independent Review (2026-03-13)

## Scope

- Reviewed `pset6_questions.tex`, `pset6_ECON1550.tex`, and the current `pset6_review.md`.
- Checked the cross-assignment dependency in `Problem Set 3/pset3_questions.tex` because PS6 Q1d-Q1e explicitly build on PS3 Q2c.
- Audited the bundled workbook and image artifacts in `Resources/Data/` and `Resources/Images/`.
- Recompiled `pset6_ECON1550.pdf`, `pset6_ECON1550_answers.pdf`, and `pset6_ECON1550_answers_short.pdf` with `latexmk`.
- Rendered the PDFs to PNG and visually inspected all pages for layout, clipping, and figure placement.

## Findings (ordered by severity)

### High

1. **Sample-window mismatch between the PS6 text, the shipped PS6 artifacts, and the referenced PS3 work** - OPEN
   - `pset6_questions.tex:43` asks for inflation data "between February 2009 and July 2023".
   - `pset3_questions.tex:262` tells students to end the carry-trade analysis in July 2023.
   - But the shipped PS6 artifacts are built on a later window:
   - `Resources/Images/q1c_us_korea_inflation_yoy_2009-01_to_2023-08.png`
   - `Resources/Images/q1d_relative_ppp_usd_overvaluation_indicator_2009-01_to_2023-08.png`
   - `Resources/Images/q1e_cumulative_returns_standard_vs_hedged_carry_trade_2009-02_to_2023-08.png`
   - `Resources/Data/ECON1550_pset6_q1.xlsx` ends on `2023-08-01` in the `Carry trade calculations` sheet.
   - Impact: a student who follows the written PS6/PS3 instructions can produce a different terminal observation than the answer key and bundled figures.
   - Recommendation: choose one canonical sample window and align the prompt, workbook, image files, and PS3 dependency. If you keep the current shipped artifacts, the minimal textual fix is likely to move PS6 to Jan 2009-Aug 2023 for Q1c-Q1d and Feb 2009-Aug 2023 for Q1e, plus a coordinated PS3 update.

### Medium

2. **Q1e uses "cumulative returns" to describe a wealth index normalized to 100, and the verbal comparison is only correct under that nonstandard interpretation** - OPEN
   - In `pset6_questions.tex:90-114`, the question and solution repeatedly say "cumulative returns".
   - In `Resources/Data/ECON1550_pset6_q1.xlsx`, the plotted series are initialized at `100` and compounded forward, so they are portfolio values / return indices rather than cumulative returns in the usual sense.
   - Final bundled values are:
   - Standard carry index: `136.5337573`
   - Hedged carry index: `575.0927887`
   - Index ratio: `4.2121x`
   - But the corresponding cumulative returns are `36.53%` and `475.09%`, whose ratio is about `13.00x`.
   - Impact: the plot label, baseline, and written interpretation point to different objects, which can confuse students about what they are supposed to graph and how to interpret the endpoint comparison.
   - Recommendation: either relabel the series as "investment value (Feb 2009 = 100)", "wealth index", or "return index", or convert the plotted values to actual cumulative returns with a baseline of `0`.

### Low

3. **The student PDF still has one cosmetic overfull line in Q2c** - OPEN
   - `pset6_ECON1550.log` reports `Overfull \hbox (11.13112pt too wide)` at `pset6_questions.tex:169-172`.
   - The rendered PDF remains readable and nothing is clipped, so this is cosmetic rather than a delivery blocker.
   - Recommendation: split the functional-form sentence across lines or move the two `L(\cdot)` definitions into display math.

## Verified Good

- The earlier Q2e inconsistency is resolved. The current solution correctly states that PPP implies `q = 1`, so the increase in `M^s` leaves `q` and `Y/Y^*` unchanged in this model.
- All three TeX targets compile successfully with `latexmk`.
- Visual inspection found no clipped text, broken solution boxes, missing figures, or bad page breaks in the current PDFs.
- The shipped workbook and the Dropbox workbook snapshot in `Resources/Data/source_downloads/pset6_q1_solution_workbook_dropbox.xlsx` are consistent with each other.

## Current Build Notes

- Student version: `3` pages.
- Full answers version: `6` pages.
- Short answers version: `3` pages.
- Non-blocking warnings currently observed:
- The single overfull line above in the student build.
- The existing package-name warning from `\usepackage{../pset}`, which is repo-level and not specific to PS6.
