# Problem Set 5 Review: Big Mac Index, PPP, and Exchange Rates

**Date**: 2026-02-28
**Reviewer**: Automated review
**File**: `pset5_questions.tex`

---

## Overview

Problem Set 5 is a single, well-structured question with 10 parts (a--j) about Purchasing Power Parity using the Big Mac Index and OECD data, focused on Argentina vs USA. The problem set is generally clear, pedagogically sound, and covers absolute and relative PPP through both theoretical and empirical lenses. There are, however, several issues that need attention, ranging from a numerical error in the solution to broken URLs and outdated data references.

---

## Text Quality: Spelling, Grammar, and Clarity

### Grammar Error

- **Line 55**: `"Explain how the OECD PPP measure relates to our definition of PPP in from the textbook (and from class)."`
  - **Issue**: "in from" is a grammatical error.
  - **Fix**: Change to `"... our definition of PPP from the textbook (and from class)."` (remove "in").

### Word Choice

- **Line 204**: `"the exchange rate depreciate more than what is implied by either of the two PPP measures."`
  - **Issue**: Subject-verb agreement. "Exchange rate" is singular.
  - **Fix**: Change to `"the exchange rate depreciated more than what is implied..."` (past tense, matching narrative).

### Style: First Person in Solutions

- **Line 82**: `"For the two countries, I chose the United States and Argentina."`
- **Line 117**: `"When I make a scatter plot..."`
  - **Issue**: Using first person in solutions is inconsistent with a formal answer key.
  - **Suggestion**: Consider rephrasing to `"The solution uses..."` or `"Using the United States and Argentina as the two countries..."`. This is a minor stylistic point.

### Paragraph Clarity

- **Lines 125--128**: The solution for part (e) says "the six datapoints with the highest values of E are all above the 45-degree line" -- this is a correct observation but could be more pedagogically precise. Since Argentina had very high inflation/depreciation in recent years, these outliers are from 2018--2023.

### Reference Consistency

- **Part (g), line 170**: References "parts e) and f)". This is correct.
- **Part (d), line 72**: Says "data for 2023" -- see Data Staleness section below.

---

## Mathematical Correctness

### CRITICAL: Numerical Error in Part (d) Solution

The solution on **line 83** states:

> "The local price of a Big Mac in local currency (variable local_price) in 2023 is 1,315 ARS for Argentina and **5.69 USD** for the United States."

And then computes:

> P/P* = 1,315 / 5.69 = 240.30

**This is incorrect in two ways:**

**Error in the US price**: The actual data shows:
- USA Jan 2023: `local_price = 5.36`
- USA Jul 2023: `local_price = 5.58`
- Annual average: **(5.36 + 5.58) / 2 = 5.47**

The value 5.69 does not appear anywhere in the 2023 data. It may have been taken from a different year or version of the data.

**Error in the division**: Even using the stated values:
- 1,315 / 5.69 = **231.11** (not 240.30)
- 1,315 / 5.47 = **240.40** (which rounds to 240.40, close to the stated 240.30)

**Conclusion**: The ratio 240.30 is approximately correct when using the actual annual average US price of 5.47, but the text incorrectly states the US price as 5.69. The stated division 1,315/5.69 = 240.30 is arithmetically wrong.

**Proposed fix** (line 83):
```
Change "5.69 USD" to "5.47 USD"
Change "240.30" to "240.40"
```

### OECD PPP Value

- **Line 89**: States OECD PPP for Argentina 2023 = 138.54
- **Current OECD data** (downloaded Feb 2026): PPP for 2023 = **139.81**
- The OECD revises historical data periodically. The original value of 138.54 matches what was available in Sep 2024 (the date on the raw data file). This is not necessarily an error to fix in the text, but should be noted.

### Exchange Rate Value

- **Line 98**: States E = 296.26 ARS/USD for 2023
- **Verified**: The OECD exchange rate for 2023 is **296.258**, which rounds to 296.26. **Correct.**

### Other Math

- The 45-degree line discussion (line 115) is correct.
- R^2 discussion (lines 145-147) is appropriate and correct.
- The correlation of 99.7% (line 216) matches the data (computed: 99.7%).
- The formula E = P/P* (line 39) is correctly stated.

---

## Data and Links Verification

### URL Status

| URL | Status | Issue |
|-----|--------|-------|
| `economist.com/big-mac-index` | **301 Redirect** | Redirects to `economist.com/interactive/big-mac-index`. Update link. |
| OECD Data Explorer | **200 OK** | Working, but the pre-filled query may need verification that it still returns the correct data view. |
| `github.com/TheEconomist/big-mac-data` | **200 OK** | Working. Repo was last updated Feb 2025. |
| Pinned commit CSV (6f8e893...) | **200 OK** | Working. This specific commit is still accessible. |
| `oecd.org/sdd/purchasingpowerparities-frequentlyaskedquestionsfaqs.htm` | **403 Forbidden** | **BROKEN**. Returns Cloudflare challenge page. The OECD reorganized their website. New URL: `https://www.oecd.org/en/data/insights/data-explainers/2024/06/purchasing-power-parities---frequently-asked-questions-faqs.html` |

### Proposed URL Fixes

- **Line 7**: Change `\url{https://www.economist.com/big-mac-index}` to `\url{https://www.economist.com/interactive/big-mac-index}`
- **Line 57**: Change the OECD FAQ URL from `https://www.oecd.org/sdd/purchasingpowerparities-frequentlyaskedquestionsfaqs.htm` to `https://www.oecd.org/en/data/insights/data-explainers/2024/06/purchasing-power-parities---frequently-asked-questions-faqs.html`

---

## Reproducibility of Results

### Data Download and Processing

All results were reproduced using `scripts/pset5_reproduce_results.py`. The script:
- Downloads Big Mac data from the pinned commit (matches existing raw data exactly)
- Downloads OECD data via SDMX REST API
- Computes all numerical values
- Generates all 9 plots with descriptive filenames

### Numerical Verification

| Value | Problem Set | Reproduced | Match? |
|-------|------------|------------|--------|
| ARG Big Mac price 2023 | 1,315 ARS | 1,315.00 | YES |
| USA Big Mac price 2023 | 5.69 USD | **5.47 USD** | **NO** |
| Big Mac P/P* | 240.30 | **240.40** | **CLOSE** (correct with 5.47) |
| OECD PPP 2023 | 138.54 | **139.81** | NO (OECD revised) |
| Exchange rate E 2023 | 296.26 | 296.26 | YES |
| Correlation BM vs OECD PPP | 99.7% | 99.7% | YES |

### Plot Verification

All 9 plots were regenerated with descriptive names. The original `a_image*` files are preserved. New files:

| Original | New Descriptive Name | Correspondence |
|----------|---------------------|----------------|
| a_image1.png | bigmac_E_vs_PPP_scatter_all.png | E vs Big Mac PPP (all years) |
| a_image6.png | bigmac_E_vs_PPP_scatter_zoomed.png | E vs Big Mac PPP (zoomed) |
| a_image7.png | oecd_E_vs_PPP_scatter_all.png | E vs OECD PPP (all years) |
| a_image8.png | oecd_E_vs_PPP_scatter_zoomed.png | E vs OECD PPP (zoomed) |
| a_image9.png | bigmac_relative_PPP_scatter.png | Relative PPP: Big Mac |
| a_image2.png | oecd_relative_PPP_scatter.png | Relative PPP: OECD |
| a_image3.png | growth_rates_timeseries.png | Growth rates time series |
| a_image4.png | bigmac_vs_oecd_PPP_scatter_all.png | Big Mac vs OECD PPP scatter |
| a_image5.png | bigmac_vs_oecd_PPP_scatter_zoomed.png | Big Mac vs OECD PPP (zoomed) |

---

## Data Updates Available

### Big Mac Data

- **Existing data** (pinned commit 6f8e893, also in Resources/Raw data): Through **July 2024** (2,231 rows)
- **Latest data** (master branch, Feb 2025): Through **January 2025** (2,302 rows, 71 new rows)
- New data includes **2025-01-01** observations for all countries
- Argentina 2024 data: Jan price=3,150 ARS (ex=821.44), Jul price=6,100 ARS (ex=931.97)
- Argentina 2025 data: Jan price=7,300 ARS (ex=1,050.00)
- Latest data saved to: `overleaf/Data/bigmac/big-mac-source-data-v2-latest.csv`

### OECD Data

- **PPP**: Now available through **2024** (was through 2023 in Sep 2024 download)
  - ARG 2024 PPP = 419.90
- **Exchange rate**: Now available through **2025**
  - ARG 2024 EXC = 914.69
  - ARG 2025 EXC = 1,240.85
- **2023 revision**: The OECD PPP for Argentina 2023 changed from 138.54 to 139.81 (a 0.9% revision)
- Fresh OECD data saved to: `overleaf/Data/oecd/oecd_ppp_exc_arg_usa.csv`

### Should the Problem Set Be Updated to Use Newer Data?

The problem set could be updated to use **2024** data instead of 2023. This would:
- Add more recent observations
- Show even more dramatic inflation in Argentina (Big Mac price rose from 1,315 ARS in 2023 to ~4,625 ARS in 2024)
- Include the Milei administration's economic reforms starting Dec 2023
- However, it would require regenerating all plots and recalculating all numerical values

**Recommendation**: Consider updating to 2024 data for the next semester. For this semester, fix only the numerical errors and broken links.

---

## Proposed Changes (by Priority)

### HIGH Priority (Errors)

| Line | Current | Proposed | Reason |
|------|---------|----------|--------|
| 55 | `"...PPP in from the textbook..."` | `"...PPP from the textbook..."` | Grammar error |
| 83 | `"5.69 USD"` | `"5.47 USD"` | Incorrect value (actual annual avg) |
| 86 | `"= 240.30"` | `"= 240.40"` | Correct computation with 5.47 |
| 204 | `"depreciate"` | `"depreciated"` | Subject-verb agreement / tense |

### MEDIUM Priority (Broken Links)

| Line | Current URL | Proposed URL | Reason |
|------|------------|-------------|--------|
| 7 | `economist.com/big-mac-index` | `economist.com/interactive/big-mac-index` | 301 redirect |
| 57 | `oecd.org/sdd/purchasingpowerparities-frequentlyaskedquestionsfaqs.htm` | `oecd.org/en/data/insights/data-explainers/2024/06/purchasing-power-parities---frequently-asked-questions-faqs.html` | 403 Forbidden |

### LOW Priority (Enhancements)

| Line | Issue | Suggestion |
|------|-------|------------|
| 73 | "data for 2023" | Consider updating to 2024 (newer data available) |
| 82 | "I chose" style | Consider `"Using Argentina and the United States:"` |
| 89 | PPP = 138.54 | OECD revised to 139.81; consider updating or noting |
| 117 | "data between 2000 and 2023" | Update end year if pinned data goes to 2024 |
| 119, 132, 158, ... | `a_image*.png` filenames | Consider renaming to descriptive names |

### Informational (No Change Needed Now)

- The pinned commit URL for Big Mac data still works
- The OECD Data Explorer link still works and loads correctly
- The existing raw data files match the pinned commit exactly
- All 9 plots are reproducible from the data
- Correlation value (99.7%) is confirmed correct

---

## Summary of Issues by Category

| Category | Count | Severity |
|----------|-------|----------|
| Numerical errors | 2 | HIGH |
| Grammar errors | 2 | HIGH |
| Broken URLs | 2 | MEDIUM |
| Data staleness | 3 | LOW |
| Style suggestions | 3 | LOW |

---

## Files Created/Modified During Review

### New Files
- `scripts/pset5_reproduce_results.py` -- Reproduction script
- `overleaf/Data/bigmac/big-mac-source-data-v2-pinned.csv` -- Pinned commit Big Mac data
- `overleaf/Data/bigmac/big-mac-source-data-v2-latest.csv` -- Latest Big Mac data (through Jan 2025)
- `overleaf/Data/oecd/oecd_ppp_exc_arg_usa.csv` -- Fresh OECD data download
- `overleaf/Problem Sets/Problem Set 5/Resources/Images/bigmac_*.png` -- 5 reproduced plots
- `overleaf/Problem Sets/Problem Set 5/Resources/Images/oecd_*.png` -- 3 reproduced plots
- `overleaf/Problem Sets/Problem Set 5/Resources/Images/growth_rates_timeseries.png` -- 1 reproduced plot

### Modified Files
- `overleaf/Data/fred/series.yml` -- Added `_bigmac` and `_oecd_ppp` metadata entries
