# ECON1550 Problem Set 5 — Comprehensive Review (2026-03-10)

## Overview

Problem Set 5 is a single, multi-part question (10 parts, 100 points) on the Big Mac Index, Purchasing Power Parity (PPP), and exchange rates. Students work with real data from The Economist and the OECD to assess absolute and relative PPP for a self-chosen country pair.

---

## Findings (ordered by severity)

### High

**Q1e solution makes an invalid statistical inference from R²** — OPEN
- File: `pset5_questions.tex`, lines 151–155
- The answer key states: "Even though the slope of 1.1310 is close to 1, the points fit the line with slope 1.1310 very well (with an R² of 0.9980), which implies that the difference between the slope of 1.1310 and the slope of 1 is unlikely to be caused by noise or measurement error."
- Why this is wrong: R² measures how well the fitted line explains variation in the dependent variable. It says nothing about whether the estimated slope is statistically different from a specific value (e.g., 1). A high R² with a large sample size makes the slope estimate more precise, but R² itself is not a test of the restriction slope = 1. One needs a standard error or a formal hypothesis test to make that claim.
- Recommendation: Either (a) replace the sentence with a descriptive statement ("the fitted slope is 1.1310 rather than 1, and the tight fit suggests the relationship is systematic"), or (b) report the standard error of the slope estimate and note that the slope is statistically significantly different from 1. Option (a) is simpler and avoids introducing hypothesis testing machinery that may be beyond the course level.

**Q1h answer key claim about "broadly similar magnitudes" in 2023–2024 is misleading** — OPEN
- File: `pset5_questions.tex`, lines 243–244
- The solution says: "One feature in favor of relative PPP is that in 2023 and 2024, all three series jump sharply and by broadly similar magnitudes."
- Looking at the growth rates plot (`growth_rates_timeseries.png`), in 2024 the Big Mac P/P\* growth is ~240%, the OECD P/P\* growth is ~130%, and E growth is ~210%. A factor-of-two difference between OECD and the other two is not "broadly similar."
- The 2023 values are closer (~40%, ~50%, ~65%) and would better support the claim.
- Recommendation: Narrow the claim to 2023 specifically, or soften to "all three series show large jumps" without claiming similar magnitudes. Alternatively, pick a different year range where the co-movement is tighter (e.g., 2019–2020).

### Medium

**Q1d prompt is clear for US-based pairs but underspecified for non-US pairs** — OPEN
- File: `pset5_questions.tex`, lines 79–86
- Related: `Resources/generated/other_countries_content.tex`, methodology section (lines 1–5)
- The question says students may pick "any two countries," but the main handout never explains that non-US pairs require cross-rate construction: E = E^{USD} / E\*^{USD} and PPP = PPP^{USD} / PPP\*^{USD}.
- The Argentina-US example works directly from the OECD series, but a student choosing UK-Japan must compute cross rates—a conceptual step only documented in the supplemental `other_countries.pdf`.
- Recommendation: Add one sentence in Q1c or Q1d, e.g., "If neither of your chosen countries is the US, construct the bilateral exchange rate and PPP as the ratio of the two countries' USD-based OECD series."

**Q1e/Q1f intercept discussion overstates its significance** — OPEN
- File: `pset5_questions.tex`, lines 153–154
- The solution says: "The intercept of the fitted line is 4.6105, which is not close to the intercept of zero predicted by PPP."
- In context, E ranges from ~1 to ~915 in the full sample. An intercept of 4.61 is tiny relative to this scale (0.5% of the range). Calling it "not close to zero" without noting the scale could confuse students.
- Recommendation: Add context, e.g., "The intercept of 4.6105 is small relative to the data range, but the systematic pattern of points above the 45-degree line at high E values is more concerning."

**Q1g solution doesn't explicitly define relative PPP before plotting** — OPEN
- File: `pset5_questions.tex`, lines 204–205
- The solution jumps to "we plot percentage changes in PPP and E rather than levels" without first stating the relative PPP equation. Since earlier parts defined absolute PPP as E = P/P\*, the solution should state: "Relative PPP says that the percentage change in E should equal the percentage change in P/P\*. In a scatter plot, relative PPP holds if points lie on the 45-degree line."
- Recommendation: Add one sentence defining relative PPP in terms of percentage changes before showing the plot.

**Answer key depends on a Dropbox URL rather than a stable reference** — OPEN
- File: `pset5_questions.tex`, line 91
- The answer for Q1d points to `other_countries.pdf` via an external Dropbox link with a session-style `st=...` parameter.
- This link is brittle for long-term reuse.
- Recommendation: Use a stable course URL or bundle the PDF directly with the distributed solution materials.

### Low

**The `other_countries.pdf` summary table overflows horizontally** — OPEN (cosmetic)
- File: `Resources/generated/other_countries_content.tex`, lines 7–28
- The `longtable` with 7 columns is slightly too wide for the page margins.
- Impact: Cosmetic only; the PDF compiles and content is readable.
- Recommendation: Accept as-is, or reduce font size / abbreviate column headers in the summary table.

**Package name mismatch warning in LaTeX logs** — OPEN (cosmetic)
- Both `pset5_ECON1550.log` and `pset5_ECON1550_answers.log` show: `LaTeX Warning: You have requested package '../pset', but the package provides 'econ1550-plots'.`
- This occurs because `pset.sty` internally loads `econ1550-plots.sty` which declares a different package name.
- Impact: None; compilation succeeds and PDF output is correct.
- Recommendation: Could be resolved by aligning `\ProvidesPackage` declarations, but not worth the effort for a cosmetic warning.

**`comment.cut` temp file in the Problem Set 5 directory** — OPEN (housekeeping)
- File: `overleaf/Problem Sets/Problem Set 5/comment.cut`
- This is a temporary file generated by the LaTeX `comment` package during compilation.
- Recommendation: Add `comment.cut` to `.gitignore` if not already present.

**Argentina is an extreme example that could mislead about PPP performance** — OPEN (pedagogical, minor)
- The full-sample Argentina scatter plots look remarkably linear (R² > 0.99) primarily because Argentina's chronic inflation produces an enormous data range that dominates the regression. The zoomed plots reveal the deviations more honestly.
- A brief note in the solution acknowledging that Argentina is an extreme case (and that PPP fares worse for stable-currency countries) would strengthen the pedagogical value.
- This is already partially addressed by the supplemental `other_countries.pdf`, which includes countries like UK-US and Germany-US where PPP clearly performs much worse.

---

## Strengths

- **Pedagogically coherent sequence**: The progression from definition (a–b) to measurement (c) to bilateral comparison (d) to absolute PPP (e–f) to relative PPP (g–h) to comparison/interpretation (i–j) builds naturally and covers the topic comprehensively.
- **Clear data-handling instructions**: The question correctly instructs students to annualize semi-annual Big Mac data by averaging, preventing a common pitfall.
- **Substantive answer key**: Solutions explain the economics and reasoning, not just the final numbers. The "Additional information (not part of the answer)" sections in parts (b) and (i) are helpful for TAs.
- **Effective use of zoomed plots**: The scatter plots at both full scale and zoomed scale in parts (e), (f), and (i) reveal different aspects of the data that a single plot would miss.
- **Strong supplemental material**: The `other_countries.pdf` with 9 country pairs provides a valuable resource for TAs and for benchmarking alternative student answers.
- **Well-chosen article**: The Economist Big Mac index article is current (January 2026) and directly relevant.
- **Balanced evaluation**: Each plot-based question asks students for evidence both for and against PPP, discouraging a one-sided narrative.

---

## Numerical Verification

All numerical claims in the answer key were verified against the raw data files:

| Claim | Source | Verified Value | Status |
|-------|--------|----------------|--------|
| ARG Jan-2024 Big Mac price | `big-mac-source-data-v2-pinned.csv` | 3,150 ARS | Matches |
| ARG Jul-2024 Big Mac price | `big-mac-source-data-v2-pinned.csv` | 6,100 ARS | Matches |
| US 2024 Big Mac price | `big-mac-source-data-v2-pinned.csv` | 5.69 USD (both semi-annual) | Matches |
| Annual average ARG price | Computed: (3150+6100)/2 | 4,625.00 ARS | Matches |
| Big Mac P/P\* | 4625/5.69 | 812.83 | Matches |
| OECD PPP (ARG, 2024) | `oecd_ppp_exc_arg_usa_pinned.csv` | 419.90104 | Matches (rounds to 419.90) |
| OECD exchange rate (ARG, 2024) | `oecd_ppp_exc_arg_usa_pinned.csv` | 914.694883 | Matches (rounds to 914.69) |
| Big Mac vs OECD PPP correlation | `pset5_reproduce_results.py` output | 99.9% | Matches |

The `pset5_reproduce_results.py` script was run and all computed values match the solution targets exactly. The pinned data file (2,231 rows) is identical to the existing file.

### Plot statistics cross-check

| Plot | Reported slope | Reported intercept | Reported R² | Plot legend |
|------|---------------|-------------------|-------------|-------------|
| E vs Big Mac PPP (full) | 1.1310 | 4.6105 | 0.9980 | Matches |
| E vs Big Mac PPP (zoomed) | 1.5197 | -0.7821 | 0.9214 | Matches |
| E vs OECD PPP (full) | 2.1766 | -0.4775 | 0.9994 | Matches |
| E vs OECD PPP (zoomed) | 1.7355 | 0.1010 | 0.9436 | Matches |
| Relative PPP Big Mac | 0.5737 | 18.8634 | 0.2938 | Matches |
| Relative PPP OECD | 1.0374 | 4.8589 | 0.5685 | Matches |
| Big Mac vs OECD PPP (full) | 1.9212 | -4.3967 | 0.9980 | Matches |
| Big Mac vs OECD PPP (zoomed) | 1.0963 | 0.7468 | 0.9438 | Matches |

All 9 images referenced in `pset5_questions.tex` exist and render correctly in the PDF.

---

## Build Check

| Target | Compiles | Pages | Errors | Warnings |
|--------|----------|-------|--------|----------|
| `pset5_ECON1550.tex` (questions) | Yes | 7 | 0 | 1 (package name, cosmetic) |
| `pset5_ECON1550_answers.tex` (full answers) | Yes | 16 | 0 | 1 (package name, cosmetic) |
| `pset5_ECON1550_answers_short.tex` (short answers) | Yes | — | 0 | — |
| `other_countries.tex` (supplemental) | Yes | — | 0 | Overfull longtable (cosmetic) |

Point total: 10 parts at 10 points each = **100 points total** (confirmed by exam class output in logs).

---

## Other Countries Supplemental Material

The `other_countries.json` configuration generates plots for 9 country pairs:

| Domestic | Foreign | Sample | Correlation (Big Mac vs OECD PPP) |
|----------|---------|--------|----------------------------------|
| China | US | 2000–2024 | 30.7% |
| UK | US | 2000–2024 | -7.1% |
| Germany | US | 2011–2024 | -28.1% |
| Japan | US | 2000–2024 | 95.6% |
| Brazil | US | 2000–2024 | 97.0% |
| UK | Japan | 2000–2024 | 74.6% |
| UK | Brazil | 2000–2024 | 94.8% |
| US | South Korea | 2000–2024 | -60.3% |
| US | India | 2011–2024 | 90.7% |

Notable: The negative correlations for China-US (-7.1%), UK-US (-28.1%), Germany-US (-28.1%), and US-South Korea (-60.3%) show that Big Mac PPP and OECD PPP can diverge substantially for some country pairs, reinforcing the points made in part (i).

---

## Release Recommendation

This is a strong, well-constructed problem set with solid pedagogy and verified data. Before treating it as final, I recommend addressing:

- **Must fix**: The R² inference in Q1e (High severity) — this teaches an incorrect statistical concept.
- **Should fix**: The "broadly similar magnitudes" claim in Q1h — easily corrected by narrowing to 2023 or softening the language.
- **Should fix**: Add the relative PPP definition in Q1g before jumping to the plot.
- **Nice to fix**: The non-US pair instruction in Q1d, the intercept context in Q1e, and the Dropbox link stability.

The numerical content, data pipeline, and plot generation are all in excellent shape.
