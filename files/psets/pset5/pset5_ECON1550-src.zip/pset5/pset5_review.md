# Problem Set 5 Review

## Overall

This is a strong problem set. The student-facing handout is clear, well scaffolded, and compiles cleanly. I did not find any critical content errors, but there are two medium-priority issues worth fixing before release, plus a small set of low-priority copyediting issues.

## Findings

### Medium

1. Broken reference in the answer key and a real compile warning

- In part 1(d), the answer key says: "Results for a selection of other countries can be found ." because the link is empty: `\href{here}{}`.
- This also triggers the only meaningful warning in the main builds: `Package hyperref Warning: Suppressing empty link`.
- Files:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:87](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L87)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_ECON1550.log](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_ECON1550.log)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_ECON1550_answers.log](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_ECON1550_answers.log)
- Recommended fix: replace the empty link with a real link or a plain-text reference to `other_countries.pdf`.

2. Non-US country pairs are allowed, but the main prompt does not fully specify how to construct them

- Part 1(d) says students may pick "any two countries," but the OECD series introduced in part 1(c) are country values against the US dollar.
- The supplementary comparison document correctly explains that non-US pairs require ratios such as `E = E^{USD} / E_*^{USD}` and `PPP = PPP^{USD} / PPP_*^{USD}`, but the main assignment does not surface that logic.
- That leaves room for inconsistent definitions of `E`, `P/P*`, and over/under-valuation when students choose pairs like UK/Japan or US/South Korea.
- Files:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:51](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L51)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:78](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L78)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/Resources/generated/other_countries_content.tex:2](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/Resources/generated/other_countries_content.tex#L2)
- Recommended fix: either restrict part 1(d) to comparisons against the US, or add one sentence in the prompt explaining how to form cross-country ratios for non-US pairs.

### Low

3. The relative-PPP solution says "percentage differences" when it means percentage changes

- The solution text describes plotting "percentage differences," but the procedure and figures are based on year-over-year percentage changes / growth rates.
- File:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:196](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L196)

4. Minor typo in part 1(e) solution

- "with an n \(R^{2}\)" should be "with an \(R^{2}\)".
- File:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:148](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L148)

5. Minor wording issue in the currency description

- "where ARS are Argentinean" should be something like "where ARS denotes Argentine pesos."
- File:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:90](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L90)

6. Part 1(j) asks for three advantages, but the answer key lists four

- This is not substantively wrong, but it reads as sloppy and slightly muddies the expected answer length.
- Files:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:278](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L278)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex:282](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/pset5_questions.tex#L282)

7. `other_countries.pdf` has an overfull summary table

- The visible output is still readable, but the log reports overfull `\hbox` warnings for the longtable summary at the top of the document.
- File:
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/Resources/generated/other_countries_content.tex:6](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/Resources/generated/other_countries_content.tex#L6)
  - [/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/other_countries.log](/Users/fduarte/Library/CloudStorage/Dropbox-Brown/Fernando Duarte/Teaching/ECON1550/Econ 1550 - 2026 Spring/ECON1550-Spring26-private/overleaf/Problem Sets/Problem Set 5/other_countries.log)

## Strengths

- The sequence is strong: definition -> measurement -> two-country comparison -> absolute PPP -> relative PPP -> interpretation -> limitations.
- The student-facing prompt gives explicit point values and useful data-handling guidance, especially the instruction to annualize semi-annual Big Mac observations.
- The answer key explains economic reasoning, not just final numbers.
- The supplementary `other_countries.pdf` is a useful companion and makes it easier to vary examples or grading benchmarks.

## Build And Verification

- `pset5_ECON1550.tex`, `pset5_ECON1550_answers.tex`, `pset5_ECON1550_answers_short.tex`, and `other_countries.tex` all compile cleanly with the project's `latexmk` configuration.
- The only meaningful warning in the main builds is the empty hyperlink in part 1(d).
- I spot-checked the 2024 Big Mac arithmetic in the answer key against `big-mac-source-data-v2-pinned.csv`: Argentina 2024 local prices `3150` and `6100` average to `4625`, the US price is `5.69`, and `4625 / 5.69 = 812.83`, matching the key.
