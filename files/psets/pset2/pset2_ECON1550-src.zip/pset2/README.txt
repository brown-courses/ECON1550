ECON 1550 Spring 26 Problem Set Source Bundle
=============================================

This folder contains LaTeX source files for Problem Set 2.

QUICK START
---------
Compile:
    pset2_ECON1550.tex

FILES
-----
- pset2_ECON1550.tex
- pset.sty (course style file)
- latexmkrc (LuaLaTeX build settings)
- README.txt (this file)
- Resources/ folder images/data files (only present if needed)

COMPILING IN OVERLEAF
---------------------
1. Create a new blank project on Overleaf
2. Open the project and set compiler to LuaLaTeX: File > Settings > Compiler > LuaLaTeX
3. Upload all files from this folder to the project root
4. Select the file you want to compile in the file tree (e.g. pset2_ECON1550.tex)
5. Compile by pressing the Recompile button in the PDF preview pane

Overleaf and LaTeX at Brown: https://libguides.brown.edu/overleaf

TROUBLESHOOTING
---------------
- Try "Recompile from scratch":
	* Click the dropdown arrow (chevron) to the right of the Recompile button
	* Select Recompile from scratch from the dropdown menu

COMPILING LOCALLY
-----------------
Requires: LuaLaTeX (included in TeX Live or MiKTeX)

Option 1 - With latexmk (recommended):
    latexmk pset2_ECON1550.tex

Option 2 - Direct compilation:
    lualatex pset2_ECON1550.tex
    (run twice for cross-references)

TROUBLESHOOTING
---------------
"Font not found" errors:
  - Ensure you're using LuaLaTeX, not pdfLaTeX, and have internet access

Missing package errors:
  - Update your TeX distribution

OTHER PROBLEMS
--------------
- Submit an issue at https://github.com/brown-courses/ECON1550/issues/new
