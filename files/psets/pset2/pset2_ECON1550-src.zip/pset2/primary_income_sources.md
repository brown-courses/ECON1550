# Primary Income Balance Sources

This document contains source materials for Problem Set 2, Question 1(b) regarding the U.S. primary income balance.

---

## Source 1: BEA U.S. International Transactions, 4th Quarter and Year 2024

**URL:** https://www.bea.gov/news/2025/us-international-transactions-4th-quarter-and-year-2024

**Release Date:** March 20, 2025

### Current Account Summary

The U.S. current-account deficit narrowed to $303.9 billion in Q4 2024, representing a 2.0% decrease from the previous quarter's revised figure of $310.3 billion. This deficit equaled 4.1% of current-dollar GDP.

For the full year 2024, the deficit widened significantly to $1.13 trillion, a 25.2% increase from 2023's $902 billion, representing 3.9% of GDP.

### Key Trade Figures (Q4 2024)

**Goods Trade:**
- Exports decreased $10.8 billion to $519.2 billion
- Imports increased $5.7 billion to $845.3 billion

**Services Trade:**
- Exports increased $7.7 billion to $287.1 billion
- Imports increased $4.8 billion to $211.0 billion

### Annual 2024 Trade Data

**Goods:**
- Exports: $2.08 trillion (up $38.0 billion)
- Imports: $3.30 trillion (up $187.7 billion)

**Services:**
- Exports: $1.11 trillion (up $80.8 billion)
- Imports: $812.2 billion (up $64.0 billion)

### Primary Income

A shift in the balance on primary income from a surplus in 2023 to a deficit in 2024 contributed to the widening of the current-account deficit. Receipts of primary income increased $58.0 billion to $1.43 trillion, and payments of primary income increased $133.9 billion to $1.44 trillion.

### Financial Account Summary

Q4 net financial transactions showed −$385.3 billion (net U.S. borrowing). Full-year 2024 registered −$1.27 trillion.

---

## Source 2: Council on Foreign Relations - The U.S. Income Balance Puzzle

**URL:** https://www.cfr.org/blog/us-income-balance-puzzle

**Authors:** Brad W. Setser and Michael Weilandt

**Published:** November 3, 2024

### Summary

This Council on Foreign Relations article challenges the narrative of American "exorbitant privilege" in international finance. The authors argue that the U.S. investment income surplus—long cited as evidence of special economic status—is largely an artifact of corporate tax avoidance rather than genuine economic superiority.

### Key Findings

#### The Disappearing Surplus

The traditional view holds that America earns more on foreign investments than it pays on external debts despite running persistent trade deficits. However, Setser and Weilandt demonstrate this advantage nearly vanishes when accounting for profit-shifting: "The income differential is now mostly a function of U.S. corporate tax avoidance" and disappears entirely excluding profits reported in low-tax jurisdictions.

#### How U.S. Investment Actually Works

Contrary to popular theory, the authors find that:

- U.S. foreign direct investment (FDI) flows essentially match inbound FDI over time
- The U.S. isn't systematically borrowing to invest abroad; rather, it swaps foreign and domestic investment
- Debt inflows finance the current account deficit, not equity purchases
- Net external interest payments now reach 1.3% of GDP and will likely increase

#### The Tax Avoidance Reality

Half of U.S. FDI value and 60% of profits derive from seven identified low-tax jurisdictions. Companies like Apple and Microsoft concentrate substantial earnings offshore through intellectual property arrangements, generating approximately $100 billion combined in Irish-based profits.

#### Future Outlook

The authors project the income surplus will move into deficit as interest rates normalize and the "low-for-long" era ends. Tax policy changes—whether competitive rate reductions or restrictions on profit-shifting—could significantly alter this trajectory.

---

## Source 3: BEA Survey of Current Business - A Look at the U.S. International Transactions (January 2025)

**URL:** https://apps.bea.gov/scb/issues/2025/01-january/0125-quarterly-international-transactions.htm

### Historical Shift to Deficit

The U.S. experienced a significant reversal in its primary income account. "The revised second-quarter 2024 primary income deficit is the first deficit since the third quarter of 2001." This marks over two decades without such a deficit, making the Q3 2024 expansion to $15.5 billion particularly noteworthy.

### Causes of the Deficit

The deterioration stemmed from declining balances across three major investment categories: direct investment, portfolio investment, and other investment earnings. According to the article, "The primary income deficit was due to decreasing balances on the three major functional categories."

### Economic Interpretation

The underlying cause reflects changing investment profitability patterns. The analysis notes that "The gradual reduction of the surplus suggests investments in the United States have been relatively more profitable than investments overseas in recent years."

In Q3 2024 specifically, primary income receipts (earnings from overseas investments) fell by $15.5 billion or 4.3 percent, primarily driven by declining direct investment earnings. Simultaneously, primary income payments decreased slightly by 1.0 percent.

This transition from surplus to deficit represents a fundamental shift in the relative returns on American versus foreign investments.

---

---

## Source 4: FRED Economic Data (St. Louis Fed)

**URL (Balance):** https://fred.stlouisfed.org/series/IEABCPIA

**URL (Receipts):** https://fred.stlouisfed.org/series/IEAXIA

**URL (Payments):** https://fred.stlouisfed.org/series/IEAMIA

### Data Series

The following FRED series from the BEA provide the complete historical data:

- **IEABCPIA**: Balance on primary income (Receipts minus Payments)
- **IEAXIA**: Primary income receipts
- **IEAMIA**: Primary income payments

All series are in millions of dollars, not seasonally adjusted, annual frequency.

### Data Range

1999 to 2024 (annual data)

### Balance on Primary Income (IEABCPIA) - Complete Series

| Year | Balance (Millions $) |
|------|---------------------|
| 1999 | 9,974 |
| 2000 | 14,632 |
| 2001 | 23,244 |
| 2002 | 17,506 |
| 2003 | 29,254 |
| 2004 | 46,583 |
| 2005 | 44,186 |
| 2006 | 15,974 |
| 2007 | 64,356 |
| 2008 | 112,019 |
| 2009 | 115,539 |
| 2010 | 169,911 |
| 2011 | 202,431 |
| 2012 | 197,859 |
| 2013 | 195,460 |
| 2014 | 200,235 |
| 2015 | 185,205 |
| 2016 | 196,442 |
| 2017 | 257,942 |
| 2018 | 255,275 |
| 2019 | 247,400 |
| 2020 | 177,717 |
| 2021 | 117,247 |
| 2022 | 118,717 |
| 2023 | 52,643 |
| 2024 | -41,039 |

---

## Key Takeaways for Problem Set 2

1. **Historical Pattern (pre-2024):** The U.S. consistently earned more on its foreign assets than it paid on its liabilities to foreigners, despite being a net debtor nation. This was sometimes called the "exorbitant privilege."

2. **2024 Shift:** For the first time in the available annual data (which begins in 1999), the U.S. primary income balance turned negative in 2024. Annual data shows receipts of $1.43 trillion vs. payments of $1.44 trillion, a deficit of approximately $41 billion.

3. **Causes:** Rising interest payments on U.S. debt, declining relative profitability of U.S. foreign investments, and the end of the "low-for-long" interest rate era.

4. **Implications:** Students should examine multiple years of data to identify when this structural shift occurred and consider its economic significance.

---

## Clarification: 2001 Quarterly vs. Annual Data

**IMPORTANT:** The BEA statement "first deficit since the third quarter of 2001" refers to **quarterly** data, not annual data.

### Quarterly Data (Q3 2001)
According to the [BEA's Q3 2001 International Transactions report](https://www.bea.gov/news/2001/us-international-transactions-third-quarter-2001):
> "The deficit on income was virtually unchanged at $5.0 billion in the third quarter."

- **Income receipts on U.S.-owned assets abroad:** $69.8 billion
- **Income payments on foreign-owned assets in the U.S.:** $73.5 billion
- **Net Q3 2001 deficit:** $5.0 billion

### Annual Data (2001)
Despite the Q3 2001 quarterly deficit, the **annual** 2001 total was **positive** (+$23.2 billion) because other quarters offset the Q3 deficit.

| Year | Annual Balance (Millions $) |
|------|----------------------------|
| 2001 | **+23,244** (positive) |

### Conclusion
- **Quarterly data:** Q3 2001 was negative (-$5 billion) — hence "first deficit since Q3 2001"
- **Annual data:** 2001 was positive (+$23.2 billion) — hence "2024 is the first annual deficit in the available data (starting 1999)"

Our plot correctly uses annual data, which shows all years from 1999–2023 as positive, with 2024 being the first negative year.

---

## Data Validation

### FRED IEABCPIA (Annual Series)
The [FRED IEABCPIA series](https://fred.stlouisfed.org/series/IEABCPIA) confirms our data exactly:
- Peak: ~$258 billion in 2017
- First negative: 2024 at -$41.0 billion
- All values 1999–2023 are positive

### YCharts
[YCharts US Balance on Primary Income](https://ycharts.com/indicators/us_balance_on_primary_income_quarterly) provides historical quarterly data back to 1960, confirming the same patterns.
